<?php
require_once "objects/DB.php";
$conn = new DB();
//$selected = ['id'=>"", 'email'=>""];
//$result = $conn->find($_POST, 'users', $selected);
//$response = ["ok"];
//if (!empty($result))
//$response = ["no"];
//echo json_encode($response);
//exit();

function send(){
    var_dump($_POST);
}
send();
?>

