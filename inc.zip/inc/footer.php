
<footer>
    footer
</footer>
<script src="public/js/jquery-3.5.1.js"></script>
<script src="public/js/init.js"></script>
</body>
</html>
