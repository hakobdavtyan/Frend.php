$(document).ready(function () {
    $('#phn').blur(function (e) {
        e.preventDefault();
        var phone = $(this).val();
        $(this).siblings($('.msg')).html('');
        $.ajax({
            url: 'response.php',
            type: 'POST',
            data: {phone: phone},
            context: $(this),
            dataType: 'json',
            success: function (data) {
                if (data[0] === "ok") {
                    $(this).after("<i class='msg fa fa-artstation'></i>");
                    $(this).siblings($('input')).attr('readonly', false);
                } else {
                    $(this).after("<i class='msg fa fa-cross'></i>");
                    $(this).siblings($('input')).attr('readonly', true);
                }
            },
            error: function (data) {
                console.log('error', data);
            }
        });
    });
    $('#email').blur(function () {
        let val = $(this).val();
        $(this).siblings($('.msg')).html('');
        $.ajax({
            url: 'response.php',
            type: 'POST',
            data: {email: val},
            context: $(this),
            dataType: 'json',
            success: function (data) {
                if (data[0] === "ok") {
                    $(this).after("<i class='msg'>V</i>")
                } else
                    $(this).after("<i class='msg'>O</i>")
            },
            error: function (data) {
                console.log('error', data);
            }
        });
    });

    $('.fr').change(function () {
        $fr = $(this).val();
        $user_id = $('[name=user_id]').val();
        $.ajax({
            url: 'response.php/send',
            type: 'POST',
            data: {
                user_id: $user_id,
                friend_id: $fr
            },
            context: $(this),
            dataType: 'json',
            success: function (data) {
                console.log('success', data);
            },
            error: function (data) {
                console.log('error', data);
            }

        });

    });
});