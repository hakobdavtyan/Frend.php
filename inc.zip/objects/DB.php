<?php
require_once "interfaces/ModelInterface.php";

class DB extends PDO implements ModelInterface
{
    const DB_TYPE = 'mysql';
    const DB_HOST = 'localhost';
    const DB_NAME = 'hakobgit_site';
    const DB_USER = 'hakobgit_site';
    const DB_PASS = 'BY?9Yl7g~Gv_';

    /**
     * DB constructor.
     */
    public function __construct()
    {
        parent::__construct(self::DB_TYPE . ':host=' . self::DB_HOST . ';dbname=' . self::DB_NAME, self::DB_USER, self::DB_PASS);
        try {
            $this->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }

    public function all($table)
    {
        try {
            $stmt = $this->prepare("SELECT * FROM $table");
            $stmt->execute();
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
            if ($result)
                return $stmt->fetchAll();
        } catch (PDOException $e) {
            echo "select error: " . $e->getMessage();
        }
    }

    public function create($obj)
    {
        try {
            $table = $obj['table'];
            unset($obj['table']);

            $query = "INSERT INTO $table ("
                . $this->return_list($obj)
                . ") VALUES( "
                . $this->return_list($obj, ':') . ")";
            $stmt = $this->prepare($query);
            foreach ($obj as $key => $index) {

                $stmt->bindValue(':' . $key, $index);
            }

            $stmt->execute();

        } catch (PDOException $e) {
            echo "error: " . $e->getMessage();
        }
    }

    public function update(array $data, $id)
    {
        // TODO: Implement update() method.
    }

    public function delete($id)
    {
        // TODO: Implement delete() method.
    }

    /**
     * @param $id
     * @param $table
     */
    public function show($id, $table)
    {
        try {
            $stmt = $this->prepare("SELECT * FROM $table WHERE 
id = :id");
            $stmt->bindValue(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
//            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
            $result = $stmt->rowCount();
            if ($result > 0)
                return $stmt->fetchObject();
        } catch (PDOException $e) {
            echo "select error: " . $e->getMessage();
        }
    }

    public function return_list($obj, $colon = "")
    {
        $str = "";
        if (!empty($obj)) {
            foreach (array_keys($obj) as $index => $key) {
                (count($obj) - 1 != $index) ?
                    $str .= $colon . $key . ", " :
                    $str .= $colon . $key. " ";
            }
            return $str;
        }
    }

    public function find(array $data, $table, array $selected = ['id'=>''])
    {
        try {
            $query = "SELECT " . $this->return_list($selected) . " 
            FROM $table WHERE " .
                $this->return_list($data)  . "=".
                $this->return_list($data, ":") ;
            $stmt = $this->prepare($query);
            $stmt->execute($data);

            $result = $stmt->rowCount();
            if ($result > 0)
//                var_dump( $stmt->fetch());die;
                return $stmt->fetch();
        } catch (PDOException $e) {
            echo "select error: " . $e->getMessage();
        }
    }
}