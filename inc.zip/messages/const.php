<?php

define('AVATAR_PATH', 'public/images/');
define('INDEX', 'index.php');
define('LOGIN', 'index.php?page=login');
define('ACCOUNT', 'index.php?page=account');
define('REGISTER', 'http://localhost:63342/viktr_hw_18/index.php?page=registration');

//tables name
define('USERS', 'users');
define('POSTS', 'posts');
define('VALID_ERROR', ' դաշտը պարտադիր է։');
define('VALID_EMAIL', ' Մուտքագրեք վավեր էլ․ հասցե');
define('VALID_PHONE', ' Մուտքագրեք վավեր հեռախոսահամար');
define('VALID_GENDER', 'Նշեք ճիշտ սեռ!!');
define('INVALID_LOGIN', ' EMAILY GOYUTYUN CHUNI KAM GRANVEQ');

